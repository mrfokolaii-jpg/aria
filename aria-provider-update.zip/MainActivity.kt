package com.mrfokolaii.aria

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mrfokolaii.aria.agent.ApiConnectionTester

class MainActivity : AppCompatActivity() {
    private data class ProviderSpec(
        val id: String,
        val title: String,
        val endpoint: String,
        val modelHint: String,
        val freeNote: String = ""
    )

    private val providers = listOf(
        ProviderSpec("openrouter", "OpenRouter", "https://openrouter.ai/api/v1", "شناسهٔ مدل رایگان، معمولاً با پسوند :free", "رایگان بودن مدل و سهمیه را در حساب OpenRouter بررسی کن."),
        ProviderSpec("huggingface", "Hugging Face Inference Router", "https://router.huggingface.co/v1", "شناسهٔ دقیق مدلِ فعال در Hugging Face", "رایگان بودن به مدل، اعتبار حساب و سهمیهٔ روز بستگی دارد."),
        ProviderSpec("groq", "Groq", "https://api.groq.com/openai/v1", "شناسهٔ مدل رایگانِ فعلی Groq", "مدل‌ها و محدودیت رایگان ممکن است تغییر کنند."),
        ProviderSpec("deepseek", "DeepSeek", "https://api.deepseek.com/v1", "شناسهٔ مدل حساب DeepSeek", "این سرویس را رایگان فرض نکن؛ قبل از استفاده قیمت حساب را بررسی کن."),
        ProviderSpec("qwen", "Qwen / Alibaba Cloud", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1", "شناسهٔ مدلِ در دسترس در حساب Qwen", "دسترسی رایگان یا اعتبار آزمایشی به حساب و منطقه بستگی دارد."),
        ProviderSpec("unorouter", "UnoRouter", "https://api.unorouter.com/v1", "مدل رایگان توسط تست سرویس شناسایی می‌شود", "تست فقط مدل‌های دارای قیمت صفر را امتحان می‌کند."),
        ProviderSpec("custom", "API سفارشی", "", "شناسهٔ دقیق مدل", "آدرس و قیمت را از ارائه‌دهندهٔ خودت بررسی کن.")
    )

    private val keyFields = mutableMapOf<String, EditText>()
    private val modelFields = mutableMapOf<String, EditText>()
    private val endpointFields = mutableMapOf<String, EditText>()
    private val statusLabels = mutableMapOf<String, TextView>()
    private lateinit var statusText: TextView
    private lateinit var widgetSwitch: Switch

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startAria()
        else showStatus("برای مکالمهٔ صوتی، دسترسی میکروفون لازم است.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showSetup()
    }

    private fun showSetup() {
        val prefs = getSharedPreferences("aria", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 28, 32, 32)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)

        fun label(parent: LinearLayout, text: String, size: Float = 16f) {
            parent.addView(TextView(this).apply {
                this.text = text
                textSize = size
                setPadding(0, 14, 0, 5)
            })
        }

        fun field(parent: LinearLayout, hintText: String, value: String, secret: Boolean = false): EditText {
            return EditText(this).apply {
                hint = hintText
                setSingleLine(true)
                textSize = 15f
                if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                setText(value)
                parent.addView(this, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ))
            }
        }

        fun button(parent: LinearLayout, text: String, action: () -> Unit) {
            parent.addView(Button(this).apply {
                this.text = text
                setOnClickListener { action() }
            })
        }

        root.addView(TextView(this).apply {
            text = "🤖 ARIA\nتنظیمات اتصال و ویجت شناور"
            textSize = 23f
        })
        label(root, "سرویس‌ها مستقل‌اند؛ هر کلید و مدل جداگانه تست می‌شود.", 14f)
        label(root, "تست اتصال به‌تنهایی سرویس فعال را عوض نمی‌کند. برای تغییر سرویس باید دکمهٔ «انتخاب برای آریا» را بزنی.", 14f)

        providers.forEach { spec ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 8, 0, 8)
            }
            label(card, spec.title, 19f)
            if (spec.freeNote.isNotBlank()) label(card, spec.freeNote, 13f)

            val keyPref = prefKey(spec.id, "api_key")
            keyFields[spec.id] = field(card, "${spec.title} API Key", prefs.getString(keyPref, "") ?: "", true)

            if (spec.id == "custom") {
                endpointFields[spec.id] = field(card, "آدرس API؛ پایه یا /v1/chat/completions", prefs.getString("custom_api_url", "") ?: "")
            } else {
                label(card, "Endpoint: ${spec.endpoint}", 12f)
            }

            val modelPref = prefKey(spec.id, "model")
            val existingModel = prefs.getString(modelPref, "") ?: ""
            modelFields[spec.id] = field(card, spec.modelHint, existingModel)

            statusLabels[spec.id] = TextView(this).apply {
                textSize = 13f
                text = "وضعیت: ${providerStatus(prefs.getBoolean(prefKey(spec.id, "test_ok"), false))}" +
                    if (prefs.getString("active_provider", "none") == spec.id) "\nسرویس انتخاب‌شده برای آریا" else ""
                setPadding(0, 4, 0, 4)
                card.addView(this)
            }
            button(card, "تست اتصال ${spec.title}") { testProvider(spec.id) }
            button(card, "انتخاب ${spec.title} برای آریا") { activateProvider(spec.id) }
            root.addView(card)
            root.addView(android.view.View(this).apply {
                setBackgroundColor(0xFFDDDDDD.toInt())
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
            })
        }

        label(root, "ویجت شناور")
        widgetSwitch = Switch(this).apply {
            text = "فعال بودن ویجت روی برنامه‌های دیگر"
            isChecked = prefs.getBoolean("floating_widget_enabled", true)
            setOnCheckedChangeListener { _, enabled ->
                saveFields()
                getSharedPreferences("aria", MODE_PRIVATE).edit()
                    .putBoolean("floating_widget_enabled", enabled).apply()
                if (enabled) ensureRunPermissions()
                else {
                    stopService(Intent(this@MainActivity, AriaOverlayService::class.java))
                    showStatus("ویجت شناور خاموش شد؛ تنظیمات و تاریخچه حفظ شدند.")
                }
            }
        }
        root.addView(widgetSwitch)

        button(root, "ذخیره تنظیمات همهٔ سرویس‌ها") {
            saveFields()
            showStatus("تنظیمات ذخیره شد؛ هیچ سرویس دیگری خودکار انتخاب نشد.")
        }
        button(root, "ذخیره و اجرای آریا") {
            saveFields()
            getSharedPreferences("aria", MODE_PRIVATE).edit().putBoolean("floating_widget_enabled", true).apply()
            widgetSwitch.isChecked = true
            ensureRunPermissions()
        }
        statusText = TextView(this).apply {
            textSize = 14f
            setPadding(0, 16, 0, 8)
        }
        root.addView(statusText)
        showStatus("کلیدها و تاریخچهٔ قبلی پاک نمی‌شوند. کلید API را برای کسی ارسال نکن.")
        setContentView(scroll)
    }

    private fun prefKey(provider: String, suffix: String) = "${provider}_$suffix"

    private fun endpointFor(provider: String): String = when (provider) {
        "openrouter" -> "https://openrouter.ai/api/v1"
        "huggingface" -> "https://router.huggingface.co/v1"
        "groq" -> "https://api.groq.com/openai/v1"
        "deepseek" -> "https://api.deepseek.com/v1"
        "qwen" -> "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"
        "unorouter" -> "https://api.unorouter.com/v1"
        "custom" -> endpointFields[provider]?.text?.toString()?.trim().orEmpty()
        else -> ""
    }

    private fun providerStatus(ok: Boolean) = if (ok) "تست موفق" else "غیرفعال یا هنوز تست نشده"

    private fun saveFields() {
        val prefs = getSharedPreferences("aria", MODE_PRIVATE)
        val edit = prefs.edit()
        providers.forEach { spec ->
            val key = keyFields[spec.id]?.text?.toString()?.trim().orEmpty()
            val model = modelFields[spec.id]?.text?.toString()?.trim().orEmpty()
            val oldKey = prefs.getString(prefKey(spec.id, "api_key"), "") ?: ""
            val oldModel = prefs.getString(prefKey(spec.id, "model"), "") ?: ""
            edit.putString(prefKey(spec.id, "api_key"), key)
            edit.putString(prefKey(spec.id, "model"), model)
            if (spec.id == "custom") {
                val url = endpointFields[spec.id]?.text?.toString()?.trim().orEmpty()
                val oldUrl = prefs.getString("custom_api_url", "") ?: ""
                edit.putString("custom_api_url", url)
                if (url != oldUrl) edit.putBoolean("custom_test_ok", false)
            }
            if (oldKey != key || oldModel != model) edit.putBoolean(prefKey(spec.id, "test_ok"), false)
        }
        // Keep old preference names compatible with earlier ARIA versions.
        edit.putString("unorouter_api_key", keyFields["unorouter"]?.text?.toString()?.trim().orEmpty())
        edit.putString("unorouter_model", modelFields["unorouter"]?.text?.toString()?.trim().orEmpty())
        edit.putString("custom_api_key", keyFields["custom"]?.text?.toString()?.trim().orEmpty())
        edit.putString("custom_model", modelFields["custom"]?.text?.toString()?.trim().orEmpty())
        edit.apply()
    }

    private fun testProvider(which: String) {
        saveFields()
        val prefs = getSharedPreferences("aria", MODE_PRIVATE)
        val key = keyFields[which]?.text?.toString()?.trim().orEmpty()
        val endpoint = endpointFor(which)
        val model = modelFields[which]?.text?.toString()?.trim().orEmpty()
        showStatus("در حال تست مستقل $which؛ سرویس فعال تغییر نمی‌کند...")
        Thread {
            val result = if (which == "unorouter") ApiConnectionTester.testUnoRouter(key, endpoint)
                else ApiConnectionTester.test(key, endpoint, model)
            runOnUiThread {
                val edit = prefs.edit().putBoolean(prefKey(which, "test_ok"), result.success)
                if (which == "unorouter" && result.success && !result.selectedModel.isNullOrBlank()) {
                    edit.putString(prefKey(which, "model"), result.selectedModel)
                    edit.putString("unorouter_model", result.selectedModel)
                    modelFields[which]?.setText(result.selectedModel)
                }
                // Do not auto-switch active_provider on a successful test.
                edit.apply()
                statusLabels[which]?.text = "وضعیت: ${providerStatus(result.success)}" +
                    if (prefs.getString("active_provider", "none") == which) "\nسرویس انتخاب‌شده برای آریا" else ""
                showStatus("${providers.first { it.id == which }.title}: ${result.message}")
            }
        }.start()
    }

    private fun activateProvider(which: String) {
        saveFields()
        val prefs = getSharedPreferences("aria", MODE_PRIVATE)
        val key = keyFields[which]?.text?.toString()?.trim().orEmpty()
        val endpoint = endpointFor(which)
        val model = modelFields[which]?.text?.toString()?.trim().orEmpty()
        val tested = prefs.getBoolean(prefKey(which, "test_ok"), false)
        if (!tested || key.isBlank() || endpoint.isBlank() || model.isBlank()) {
            showStatus("برای انتخاب این سرویس، کلید و مدل/آدرس را کامل کن و اول تست موفق بگیر.")
            return
        }
        prefs.edit().putString("active_provider", which).apply()
        providers.forEach { spec ->
            statusLabels[spec.id]?.text = "وضعیت: ${providerStatus(prefs.getBoolean(prefKey(spec.id, "test_ok"), false))}" +
                if (spec.id == which) "\nسرویس انتخاب‌شده برای آریا" else ""
        }
        stopService(Intent(this, AriaOverlayService::class.java))
        showStatus("${providers.first { it.id == which }.title} با انتخاب خودت فعال شد. برای اعمال، ویجت را دوباره اجرا کن.")
    }

    private fun ensureRunPermissions() {
        if (!Settings.canDrawOverlays(this)) {
            showStatus("برای ویجت، مجوز نمایش روی برنامه‌های دیگر را فعال کن.")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        startAria()
    }

    private fun startAria() {
        val prefs = getSharedPreferences("aria", MODE_PRIVATE)
        if (!prefs.getBoolean("floating_widget_enabled", true)) {
            showStatus("ویجت خاموش است.")
            return
        }
        try {
            ContextCompat.startForegroundService(this, Intent(this, AriaOverlayService::class.java))
            showStatus("درخواست اجرای آریا ارسال شد.")
        } catch (e: Exception) {
            showStatus("خطای اجرای آریا: ${e.javaClass.simpleName}")
        }
    }

    private fun showStatus(text: String) {
        if (::statusText.isInitialized) statusText.text = text
        else Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }
}
